import pytest
from httpx import AsyncClient, ASGITransport
from app.main import app
from app.core.config import settings

@pytest.mark.asyncio
async def test_orders_and_capacity_limit_rule():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        headers = {"Authorization": "Bearer test_valid_token"}
        slot_time = "2026-10-20T10:00:00Z"

        # Đặt các yêu cầu hợp lệ cho tới giới hạn MAX_SLOT_CAPACITY
        max_cap = settings.MAX_SLOT_CAPACITY
        for i in range(max_cap):
            payload = {
                "item_id": f"item_{i}",
                "scheduled_time": slot_time,
                "notes": f"Đơn hàng hợp lệ số {i}"
            }
            resp = await client.post("/api/v1/orders", json=payload, headers=headers)
            assert resp.status_code == 201
            assert resp.json()["status"] == "CONFIRMED"

        # Đơn tiếp theo cùng slot_time phải bị từ chối theo BR-01 (400 Bad Request)
        payload_overflow = {
            "item_id": "item_overflow",
            "scheduled_time": slot_time,
            "notes": "Cố tình đặt vượt công suất"
        }
        resp_overflow = await client.post("/api/v1/orders", json=payload_overflow, headers=headers)
        assert resp_overflow.status_code == 400
        assert "đạt giới hạn tối đa" in resp_overflow.json()["detail"]

@pytest.mark.asyncio
async def test_health_check_and_catalog():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        resp_health = await client.get("/api/v1/health")
        assert resp_health.status_code == 200
        assert resp_health.json()["status"] == "healthy"

        resp_cat = await client.get("/api/v1/catalog")
        assert resp_cat.status_code == 200
        assert isinstance(resp_cat.json(), list)
